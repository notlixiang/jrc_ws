#!/bin/bash
source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun soccer_maxon soccer_maxon_node
done &

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun velocity_smooth velocity_smooth 
done

