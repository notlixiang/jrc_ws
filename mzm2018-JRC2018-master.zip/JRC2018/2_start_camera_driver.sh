#!/bin/bash
source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun camera_driver kinect_driver
done &

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun camera_driver kinect_server
done &

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun tf static_transform_publisher 0 0 0  0 0 0 1 /camera_link /camera_rgb_optical_frame 1000
done