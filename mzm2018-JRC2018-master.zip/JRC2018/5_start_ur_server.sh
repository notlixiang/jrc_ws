#!/bin/bash
source devel/setup.bash
roslaunch ur_modern_driver ur10_bringup.launch&
sleep 2s
source devel/setup.bash
rosrun ur_pick_srv_v3 ur_pick_srv_v3_node