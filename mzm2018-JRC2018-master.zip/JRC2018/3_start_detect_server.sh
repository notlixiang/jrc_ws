#!/bin/bash
source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun detect_server ssd_main_show.py
done 