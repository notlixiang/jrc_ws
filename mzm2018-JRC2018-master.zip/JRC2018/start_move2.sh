#!/bin/bash
source devel/setup.bash
roslaunch agv_tcp_velocity laser.launch&
sleep 1s
source devel/setup.bash
roslaunch ira_laser_tools laserscan_multi_merger.launch&
sleep 1s
source devel/setup.bash
roslaunch laser_scan_matcher demo.launch&
sleep 1s
source devel/setup.bash
rosrun map_server map_server /home/agv/jrc_move2_ws/map/1218_big.yaml&
sleep 1s
source devel/setup.bash
roslaunch amcl amcl_omni.launch&
#
sleep 2s

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun soccer_maxon soccer_maxon_node
done &

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun jrc_move2 jrc_move2_initialpose 
done &

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun jrc_move2 jrc_move2 
done &