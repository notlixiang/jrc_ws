#!/bin/bash

echo ""
echo "RUNNING UR EE!"

echo ""
echo "Getting IO permission..."
sudo chmod 777 /dev/ttyACM0


for (( i = 0; ; i++ )); do
	echo ""
	echo "Refresh ROS environment..."
	rospack profile&&
	source devel/setup.bash&&
	echo ""
	echo "Start ROS nodes..."
	rosrun ur_ee_server ur_ee_server_node
	echo "twist_service"
done &









