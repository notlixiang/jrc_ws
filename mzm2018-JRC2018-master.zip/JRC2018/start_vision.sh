#!/bin/bash
source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun detect_server ssd_main_show.py
done &

sleep 2s

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun pose_server pose
done &

source devel/setup.bash
for (( i = 0; ; i++ )); do
	rosrun pose_server pose_center_normal
done 

