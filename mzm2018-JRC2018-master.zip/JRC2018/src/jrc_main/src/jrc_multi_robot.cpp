#include <iostream>
#include "ros/ros.h"
#include <tf/transform_listener.h>
#include "jrc_srvs/rgbd_image.h"
#include "jrc_srvs/bbox_msgs.h"
#include "jrc_srvs/obj_6d.h"
#include "jrc_srvs/call_grasp.h"
#include "jrc_srvs/call_grasp_state.h"
#include "jrc_srvs/call_twist.h"
#include "jrc_srvs/grasp.h"
#include "jrc_srvs/smooth.h"

using namespace std;
static const int TIMEOUT = 240; // 300秒直接去倾倒处
static int timeleft = TIMEOUT;
static double starttime = 0;
ros::Time roscurrent;


const static int TOTAL_OBJ_NUM = 10;
const static int TOTAL_AGV_POSI = 10;
static int checkout_side = 0;

const static int object_list[TOTAL_OBJ_NUM]     = {2,4,6,8,10,12,14,16,17,18};
//0 is un-grasped;
//1 is grasped;
//2 is not pick in this around;
//3 is need detect again;
//4 is need grasp again
static int object_status[TOTAL_OBJ_NUM]   = {0,0,0,0,0,0,0,0,0,0};


/** ###### DESK TYPE */
const int CABINET       = 1;
const int DESK          = 2;

/** ######  AGV Status Definition */
const int UN_REACHED    = 0;
const int VISITING      = 1;
const int FINISHED      = 2;

/** ######  AGV Position Definition */
const int AGVHOME       = 0;
const int DESK1         = 1;
const int CABINET1      = 3;
const int DESK2         = 4;
const int CABINET2      = 6;
const int CHECKOUT      = 9;

static int agv_posi_status[TOTAL_AGV_POSI]  = {0,0,0,0,0,0,0,0,0,0};

const int WORKING_MOTION = 1;
const int TRANSIENT_MOTION = 0;
const static float agv_motion_status[TOTAL_OBJ_NUM] = {1,1,0,1,1,0,1,0,0,1};  // 作业点是1, 过渡点是0


const int CALL_SRV_FAIL = -13;

//agv postion point
geometry_msgs::Pose point[10];

class object_info
{
public:
    std::vector<int32_t> info;
};

void  get_point_parameter()
{
    //起始点
    point[0].position.x = -2.934;//-2.935;
    point[0].position.y = -1.200;//-1.550;
    point[0].position.z = 0.038;//0.045;

    //第一个抓取点
    point[1].position.x = -2.360;//-2.254;
    point[1].position.y = -3.571;//-3.820;
    point[1].position.z = -3.118;//-3.127;

    //过渡点
    point[2].position.x = 2.060;//2.037;
    point[2].position.y = -0.744;//-1.004;
    point[2].position.z = 0.058;//0.064;

    //第二抓取点
    point[3].position.x = 2.678;//2.778;
    point[3].position.y = -3.389;//-3.607;
    point[3].position.z = -3.132;//-3.082;

    //第三抓取点
    point[4].position.x = 1.983;//2.051;
    point[4].position.y = 4.356;//4.108;
    point[4].position.z = 0.092;//0.060;

    //过渡点
    point[5].position.x = 1.983;//2.647;
    point[5].position.y = 4.356;//1.703;
    point[5].position.z = 0.092;//-3.100;

    //第四抓取点
    point[6].position.x = -2.988;//-2.986;
    point[6].position.y = 4.037;//3.803;
    point[6].position.z = 0.096;//0.055;

    //过渡点
    point[7].position.x = -2.324;//-2.313;
    point[7].position.y = 1.504;//1.209;
    point[7].position.z = -3.086;//-3.101;

    //过渡点
    point[8].position.x = -6.365;//-6.343;
    point[8].position.y = 4.287;//5.308;
    point[8].position.z = -1.551;//-1.546;

    //倾倒点
    point[9].position.x = -6.465;//-6.565;
    point[9].position.y = 3.287;//4.075;
    point[9].position.z = -1.551;//-1.558;

    //过渡点
    point[10].position.x = 6.217;//6.038;
    point[10].position.y = -3.680;//-4.050;
    point[10].position.z = 1.597;//1.558;

    //倾倒点
    point[11].position.x = 6.317;//6.219;
    point[11].position.y = -2.680;//-2.908;
    point[11].position.z = 1.597;//1.558;

    //kaojing zhuxitai chufadian
    //5.861, 4.180, -3.121


}

bool checkTimeOut(ros::Time& current) {
    double c = current.toSec();
    if (c - starttime >= timeleft) {
        cout<<"Time out!!!"<<endl;
        return true;
    }
    return false;
}

class grid_grasp
{
private:
    ros::NodeHandle nh;
    ros::ServiceClient detect_client;
    ros::ServiceClient pose_client;
    ros::ServiceClient pose_center_normal_client;
    ros::ServiceClient ur10_client;
    ros::ServiceClient grasp_client;
    ros::ServiceClient grasp_state_client;
    ros::ServiceClient twist_client;
    ros::ServiceClient agv_client;
    int object_label;
    int twist_angle;
    geometry_msgs::Pose object_pose;
    int bbox_label;
    int bbox_xmin;
    int bbox_ymin;
    int bbox_xmax;
    int bbox_ymax;
    int fail_status;
    int ss;
    bool grasp_state_bool;

public:
    grid_grasp()
    {
        detect_client = nh.serviceClient<jrc_srvs::bbox_msgs>("bbox");
        pose_client = nh.serviceClient<jrc_srvs::obj_6d>("object_pose");
        pose_center_normal_client = nh.serviceClient<jrc_srvs::obj_6d>("object_pose_central_normal");
        ur10_client = nh.serviceClient<jrc_srvs::grasp>("ur_grasp");
        grasp_client = nh.serviceClient<jrc_srvs::call_grasp>("call_grasp");
        grasp_state_client = nh.serviceClient<jrc_srvs::call_grasp_state>("call_grasp_state");
        twist_client = nh.serviceClient<jrc_srvs::call_twist>("call_twist");
        agv_client = nh.serviceClient<jrc_srvs::smooth>("agv_move");
        object_label = -1;
        twist_angle = 0;
        bbox_label = -1;
        bbox_xmin  = 0;
        bbox_ymin  = 0;
        bbox_xmax  = 0;
        bbox_ymax  = 0;
        fail_status = 0;
        ss = 1;
        grasp_state_bool = 1;

    }
    ~grid_grasp()
    {}
    int agv_service(geometry_msgs::Pose& point, float status)
    {
        jrc_srvs::smooth agv_srv;
        geometry_msgs::Quaternion quat1;
        quat1.x = point.orientation.x;
        quat1.y = point.orientation.y;
        quat1.z = point.orientation.z;
        quat1.w = point.orientation.w;

        agv_srv.request.x = point.position.x;
        agv_srv.request.y = point.position.y;
        agv_srv.request.theta = tf::getYaw(quat1);
        agv_srv.request.status = status;
        if(agv_client.call(agv_srv))
        {
            ROS_INFO("success");
            ROS_INFO("the response is %ld", (long int)agv_srv.response.mark);
            cout<<"Finish agv service."<<endl;
            return 1;
        }
        else
        {
            cout<<"AGV Servrice failed."<<endl;
            return 0;
        }
        sleep(1);
    }

    int agv_move2_service(geometry_msgs::Pose& point, const int& status)
    {
        jrc_srvs::smooth agv_srv;

        agv_srv.request.x = point.position.x;
        agv_srv.request.y = point.position.y;
        agv_srv.request.theta = point.position.z;
        agv_srv.request.status = status;

        if(agv_client.call(agv_srv))
        {
            ROS_INFO("success");
            ROS_INFO("the response is %ld", (long int)agv_srv.response.mark);
            cout<<"Finish agv service."<<endl;
            return 1;
        }
        else
        {
            cout<<"AGV Servrice failed."<<endl;
            return 0;
        }
        sleep(1);
    }

    int update_object_status(int object_label, int state)
    {
        for(int i=0;i<10;i++)
        {
            if(object_label == object_list[i])
            {
                object_status[i] = state;
            }
        }
        return 1;
    }

    int get_object_status(int object_label)
    {
        int state = 0;
        for(int i=0;i<10;i++)
        {
            if(object_label == object_list[i])
            {
                state = object_status[i];
            }
        }
        return state;
    }

    int twist_service(int object_label, int angle)
    {
        jrc_srvs::call_twist twist_srv;
        if((object_label == 2) || (object_label == 5) || (object_label == 6) || (object_label == 7) || (object_label == 13) || (object_label == 14)|| (object_label == 17))
            angle = 90;
        else if((object_label == 1) || (object_label == 3) || (object_label == 4) || (object_label == 8) || (object_label == 9) ||
                (object_label == 10) || (object_label == 11) || (object_label == 12) || (object_label == 15) || (object_label == 16)
                || (object_label == 18))
            angle = 180;
        twist_srv.request.angle = angle;
        if (twist_client.call(twist_srv))
        {
            sleep(1);
            cout<<"Finish twist service."<<endl;
            return 1;
        }
        else
        {
            cout<<"Twist Servrice failed."<<endl;
            return 0;
        }

    }

    int grasp_state_service(bool &grasp_state)
    {
        jrc_srvs::call_grasp_state grasp_state_srv;
        // grasp_state_srv.request.grasp = grasp_state_signal;
        if (grasp_state_client.call(grasp_state_srv))
        {
            if(grasp_state_srv.response.grasped == true)
            {
                cout<<"Grasp success."<<endl;
                grasp_state = 1;
                return 1;
            }
            else
            {
                cout<<"Grasp failed."<<endl;
                grasp_state = 0;
                return 1;
            }
        }
        else
        {
            cout<<"Grasp state service failed."<<endl;
            return 0;
        }
    }

    int grasp_service(bool grasp_signal)
    {
        jrc_srvs::call_grasp grasp_srv;
        grasp_srv.request.grasp = grasp_signal;
        if (grasp_client.call(grasp_srv))
        {
            cout<<"Finish grasp service."<<endl;
            return 1;
        }
        else
        {
            cout<<"Grasp Servrice failed."<<endl;
            return 0;
        }
    }

    int ur_10_service_move(
            int mode_,int agv_)
    {
        jrc_srvs::grasp ur10_srv_;
        ur10_srv_.request.mode = mode_;
        ur10_srv_.request.agv_position = agv_;
        if(ur10_client.call(ur10_srv_))
        {
            if((bool)ur10_srv_.response.result.data)
            {
                cout<<"Finish ur10 service."<<endl;
                return 1;
            }
            else
            {
                ROS_ERROR("ur10 action failed!");
                return 0;
            }
        }
        else
        {
            cout<<"Error in calling service."<<endl;
            return 0;
        }
    }

    int ur_10_service_grasp(
            int mode_,int agv_,int id_,geometry_msgs::Pose pose_,int &fail_status_)
    {
        jrc_srvs::grasp ur10_srv_;
        ur10_srv_.request.mode = mode_;
        ur10_srv_.request.agv_position = agv_;
        ur10_srv_.request.id = id_;
        ur10_srv_.request.pose = pose_;
        if(ur10_client.call(ur10_srv_))
        {
            if((bool)ur10_srv_.response.result.data)
            {
                fail_status_ = 0;
                cout<<"Finish ur10 service."<<endl;
                return 1;
            }
            else
            {                                                  //2 object pose is invaild
                fail_status_ = ur10_srv_.response.fail_status; //1 object is not at observe place
                ROS_ERROR("ur10 action failed!");
                return 0;
            }
        }
        else
        {
            cout<<"Error in calling service."<<endl;
            return 0;
        }
    }

    int pose_estimation(
            int bbox_label, int bbox_xmin, int bbox_ymin, int bbox_xmax, int bbox_ymax,
            int &object_label, geometry_msgs::Pose &object_pose)
    {
        jrc_srvs::obj_6d pose_srv;
        pose_srv.request.start = 1;
        pose_srv.request.label = bbox_label;
        pose_srv.request.xmin  = bbox_xmin;
        pose_srv.request.ymin  = bbox_ymin;
        pose_srv.request.xmax  = bbox_xmax;
        pose_srv.request.ymax  = bbox_ymax;
        if(pose_client.call(pose_srv))
        {
            if(pose_srv.response.result == 1)
            {
                object_label = pose_srv.response.label;
                object_pose = pose_srv.response.obj_pose;
                cout<<"Object_label:"<<object_label<<endl<<" object pose:"<< object_pose <<endl;
                cout<<"Finish pose service."<<endl;
                return 1;
            }
            else
            {
                cout<<"Error in object pose estimation."<<endl;
                return 2;
            }
        }
        else
        {
            cout<<"Error in calling pose ppf estimation service."<<endl;
            return 0;
        }
    }

    int pose_center_normal_estimation(
            int bbox_label, int bbox_xmin, int bbox_ymin, int bbox_xmax, int bbox_ymax,
            int &object_label, geometry_msgs::Pose &object_pose)
    {
        jrc_srvs::obj_6d pose_srv;
        pose_srv.request.start = 1;
        pose_srv.request.label = bbox_label;
        pose_srv.request.xmin  = bbox_xmin;
        pose_srv.request.ymin  = bbox_ymin;
        pose_srv.request.xmax  = bbox_xmax;
        pose_srv.request.ymax  = bbox_ymax;
        if(pose_center_normal_client.call(pose_srv))
        {
            if(pose_srv.response.result == 1)
            {
                object_label = pose_srv.response.label;
                object_pose = pose_srv.response.obj_pose;
                cout<<"Object_label:"<<object_label<<endl<<" object pose:"<< object_pose <<endl;
                cout<<"Finish pose center normal service."<<endl;
                return 1;
            }
            else
            {
                cout<<"Error in object pose center normal estimation."<<endl;
                return 2;
            }
        }
        else
        {
            cout<<"Error in calling pose center normal estimation service."<<endl;
            return 0;
        }
    }

    int object_detection(
            int &bbox_label, int &bbox_xmin, int &bbox_ymin, int &bbox_xmax, int &bbox_ymax)
    {
        bbox_label = -1;
        bbox_xmin  = 0;
        bbox_ymin  = 0;
        bbox_xmax  = 0;
        bbox_ymax  = 0;
        jrc_srvs::bbox_msgs detect_srv;
        object_info objects[20];
        detect_srv.request.start = 1;
        if(detect_client.call(detect_srv))
        {
            if(detect_srv.response.result == 1)
            {
                cout<<"Get detection result!"<<endl;
                objects[0].info  = detect_srv.response.object1;
                objects[1].info  = detect_srv.response.object2;
                objects[2].info  = detect_srv.response.object3;
                objects[3].info  = detect_srv.response.object4;
                objects[4].info  = detect_srv.response.object5;
                objects[5].info  = detect_srv.response.object6;
                objects[6].info  = detect_srv.response.object7;
                objects[7].info  = detect_srv.response.object8;
                objects[8].info  = detect_srv.response.object9;
                objects[9].info  = detect_srv.response.object10;
                objects[10].info = detect_srv.response.object11;
                objects[11].info = detect_srv.response.object12;
                objects[12].info = detect_srv.response.object13;
                objects[13].info = detect_srv.response.object14;
                objects[14].info = detect_srv.response.object15;
                objects[15].info = detect_srv.response.object16;
                objects[16].info = detect_srv.response.object17;
                objects[17].info = detect_srv.response.object18;
                objects[18].info = detect_srv.response.object19;
                objects[19].info = detect_srv.response.object20;
                for(int i=0;i<20;i++)
                {
                    if(objects[i].info.size()>0)
                    {
                        for(int j=0;j<10;j++)
                        {
                            if((object_list[j] == objects[i].info[0])&&((object_status[j] == 0)||(object_status[j] == 3)||(object_status[j] == 4)))
                            {
                                // object_status[j] = 2;
                                bbox_label = objects[i].info[0];
                                bbox_xmin  = objects[i].info[1];
                                bbox_ymin  = objects[i].info[2];
                                bbox_xmax  = objects[i].info[3];
                                bbox_ymax  = objects[i].info[4];
                                cout<<"Grasp object ID:"<<bbox_label<<endl;
                                i = 21;
                                break;
                            }
                        }
                    }
                }
                cout<<"Object label:"<<bbox_label<<" xmin:"<<bbox_xmin<<" ymin:"<<bbox_ymin
                   <<" xmax:"<<bbox_xmax<<" ymax:"<<bbox_ymax<<endl;
                cout<<"Finish detection service."<<endl;
                return 1;
            }
            else
            {
                cout<<"Error in object detection."<<endl;
                return 2;
            }
        }
        else
        {
            cout<<"Error in calling object detection service."<<endl;
            return 0;
        }
    }

    bool run(int grasp_mode,int grasp_agv_position)
    {
        roscurrent = ros::Time::now();
        if(checkTimeOut(roscurrent)){
            ur_10_service_move(3,1);
            twist_service(-1,90);

            ss = agv_move2_service(point[checkout_side], 0);
            while(ss == 0)
            {
                ss = agv_move2_service(point[checkout_side], 0);
            }
            ss = agv_move2_service(point[checkout_side+1], 1);
            twist_service(-1,0);
            ur_10_service_move(13,1);
            exit(0);
        }

        while(1)
        {
            cout<<"before object_status:";
            for(int i=0;i<10;i++)
            {
                cout<<object_status[i]<<",";
            }
            cout<<endl;
            ur_10_service_move(grasp_mode,grasp_agv_position);
            twist_service(-1,90);
            object_detection(bbox_label,bbox_xmin,bbox_ymin,bbox_xmax,bbox_ymax);
            if(bbox_label == -1)
            {
                cout<<"No target object in observe area."<<endl;
                break;
            }
            else
            {
                object_label = bbox_label;
            }

            if(object_label ==4)
            {
                if(get_object_status(object_label) == 0)
                {
                    ss = pose_center_normal_estimation(bbox_label,bbox_xmin,bbox_ymin,bbox_xmax,bbox_ymax,object_label,object_pose);
                    if(ss == 2)
                    {
                        // update_object_status(object_label,3);
                        ss = 1;
                        continue;
                    }
                }
                else
                {
                    ss = pose_estimation(bbox_label,bbox_xmin,bbox_ymin,bbox_xmax,bbox_ymax,object_label,object_pose);
                    if(ss == 2)
                    {
                        ss = 1;
                        continue;
                    }
                }
            }
            else
            {
                if(get_object_status(object_label) == 0)
                {
                    ss = pose_estimation(bbox_label,bbox_xmin,bbox_ymin,bbox_xmax,bbox_ymax,object_label,object_pose);
                    if(ss == 2)
                    {
                        update_object_status(object_label,3);
                        ss = 1;
                        continue;
                    }
                }
                else
                {
                    ss = pose_center_normal_estimation(bbox_label,bbox_xmin,bbox_ymin,bbox_xmax,bbox_ymax,object_label,object_pose);
                    if(ss == 2)
                    {
                        ss = 1;
                        continue;
                    }
                }
            }

            ur_10_service_grasp(14,grasp_agv_position,object_label,object_pose,fail_status);
            if(fail_status == 1)// object is not in observe area
            {
                cout<<"target object is not in observe area."<<endl;
                update_object_status(object_label,2);
                continue;
            }
            else if(fail_status == 2)// object is invalid
            {
                cout<<"object is invalid."<<endl;
                if(get_object_status(object_label) == 3)
                {
                    update_object_status(object_label,2);
                    continue;
                }
                else
                {
                    update_object_status(object_label,3);
                    continue;
                }
            }

            twist_service(bbox_label,0);
            grasp_service(1);
            ss = ur_10_service_grasp(1,grasp_agv_position,object_label,object_pose,fail_status);
            if(ss == 0)
            {
                ss = 1;
                continue;
            }
            sleep(1);
            ur_10_service_move(2,grasp_agv_position);
            grasp_state_service(grasp_state_bool);
            if(grasp_state_bool == 0)
            {
                ROS_ERROR("NO OBJECT IN END!");
                grasp_state_bool = 1;
                if(get_object_status(object_label) == 4)
                {
                    update_object_status(object_label,2);
                    continue;
                }
                else
                {
                    update_object_status(object_label,4);
                    continue;
                }
            }
            ur_10_service_move(3,grasp_agv_position);
            twist_service(-1,90);
            grasp_service(0);
            sleep(1);

            cout<<"object_status:";
            for(int i=0;i<10;i++)
            {
                if(object_list[i] == object_label)
                    object_status[i] = 1;
                cout<<object_status[i]<<",";
            }
            cout<<endl;

            object_label = 0;
            bbox_label = -1;
            bbox_xmin  = 0;
            bbox_ymin  = 0;
            bbox_xmax  = 0;
            bbox_ymax  = 0;
        }
        cout<<"object_status:";
        for(int i=0;i<10;i++)
        {
            cout<<object_status[i]<<",";
            if(object_status[i] == 2)
                object_status[i] = 0;
        }
        cout<<endl;

        return 1;
    }

};


int main(int argc, char** argv) 
{
    cout << "Hello JRC" << endl;
    ros::init(argc, argv, "jrc_multi_robot");
    ros::Time::init();
    grid_grasp grasp;
    get_point_parameter();
    ROS_INFO("Start JRC MAIN!");
    int priority_array[4];
    int finish = atoi(argv[5]);
    checkout_side = atoi(argv[6]) - 1;
    for(int i=0;i<4;i++)
    {
        priority_array[i] = atoi(argv[i+1]);
        cout<<"priority_array: "<<i<< " : "<<priority_array[i]<<endl;
    }
    
    geometry_msgs::Pose location_array[4][2];
    geometry_msgs::Pose checkout_array[2][2];
    int k = 0;
    for(int i = 0;i<4;i++)
    {
        for(int j=0;j<2;j++)
        {

            location_array[i][j] = point[k++];
        }
    }
    for(int i = 0;i<2;i++)
    {
        for(int j=0;j<2;j++)
        {

            checkout_array[i][j] = point[k++];
        }
    }
    int desk_flag[4] = {0,0,0,0}; //0 is unreach;1 is reached; 2 is block
    tf::TransformListener listener;
    tf::StampedTransform transform;

    starttime = ros::Time::now().toSec();
    
    while(1)
    {
        if(finish == 1)
            break;
        bool desk_is_full = true;
        bool time_up = true;
        bool object_list_full = true;
        for(int i=0;i<4;i++)
        {
            if(desk_flag[i] == 0)
            {
                desk_is_full = false;
                break;
            }
        }
        for(int i=0;i<10;i++)
        {
            if(object_status[i] != 1)
            {
                object_list_full = false;
                break;
            }
        }

        roscurrent = ros::Time::now();
        time_up = checkTimeOut(roscurrent);

        cout<<"desk_is_full:"<<desk_is_full<<" "<<"object_list_full:"<<object_list_full<<" "<<"time_up:"<<time_up<<endl;

        if(desk_is_full || object_list_full || time_up) //time up is not add
        {
            break;
        }

        int goal_location_desk = 0;
        geometry_msgs::Pose goal_location;

        for(int i=0;i<4;i++)
        {
            if(desk_flag[priority_array[i]-1] == 0)
            {
                goal_location_desk = priority_array[i]-1;
                break;
            }
        }
        //read tf
        try
        {
            listener.waitForTransform("/base_link", "/map", ros::Time(0), ros::Duration(10.0) );
            listener.lookupTransform("/base_link", "/map", ros::Time(0), transform);
        }
        catch (tf::TransformException ex)
        {
            ROS_ERROR("%s",ex.what());
            ros::Duration(1.0).sleep();
        }
        geometry_msgs::PoseStamped point1_in_map, point1_in_baselink;
        geometry_msgs::PoseStamped point2_in_map, point2_in_baselink;

        point1_in_map.header.frame_id = "/map";
        point1_in_map.header.stamp = ros::Time::now();
        point1_in_map.pose.position.x = location_array[goal_location_desk][0].position.x;
        point1_in_map.pose.position.y = location_array[goal_location_desk][0].position.y;
        point1_in_map.pose.position.z = 0.0;
        point1_in_map.pose.orientation = tf::createQuaternionMsgFromYaw(location_array[goal_location_desk][0].position.z);

        point2_in_map.header.frame_id = "/map";
        point2_in_map.header.stamp = ros::Time::now();
        point2_in_map.pose.position.x = location_array[goal_location_desk][1].position.x;
        point2_in_map.pose.position.y = location_array[goal_location_desk][1].position.y;
        point2_in_map.pose.position.z = 0.0;
        point2_in_map.pose.orientation = tf::createQuaternionMsgFromYaw(location_array[goal_location_desk][1].position.z);

        point1_in_baselink.header.frame_id = "/base_link";
        point1_in_baselink.header.stamp = ros::Time::now();
        point1_in_baselink.pose.orientation.w = 1;

        point2_in_baselink.header.frame_id = "/base_link";
        point2_in_baselink.header.stamp = ros::Time::now();
        point2_in_baselink.pose.orientation.w = 1;

        listener.transformPose("/base_link",ros::Time(0), point1_in_map, "/map", point1_in_baselink);
        listener.transformPose("/base_link",ros::Time(0), point2_in_map, "/map", point2_in_baselink);

        //find the closest point of the goal_location_desk
        double toPoint1 = hypot(fabs(point1_in_baselink.pose.position.x),fabs(point1_in_baselink.pose.position.y));
        double toPoint2 = hypot(fabs(point2_in_baselink.pose.position.x),fabs(point2_in_baselink.pose.position.y));

        cout<<"toPoint1:"<<toPoint1<<endl;
        cout<<"toPoint2:"<<toPoint2<<endl;
         for(int i=0;i<4;i++)
        {
            cout<<"desk_flag: "<<i<<" : "<<desk_flag[i]<<endl;
        }

        if(toPoint1 > toPoint2)
        {
            goal_location = location_array[goal_location_desk][1];
        }
        else
        {
            goal_location = location_array[goal_location_desk][0];
        }
        cout<<"goal_location_desk id:"<<goal_location_desk<<endl;
        cout<<"goal_location:"<<goal_location<<endl;

        grasp.ur_10_service_move(3,1);
        grasp.twist_service(-1,90);

        //call agv service(x,y is position, z is theta)
        int ss = 1;
        ss = grasp.agv_move2_service(goal_location, 0);
        if(ss == 0)
        {
            desk_flag[goal_location_desk] = 2;
            continue;
        }
        else
        {
            roscurrent = ros::Time::now();
            if(checkTimeOut(roscurrent)){
                break;
            }

            if(goal_location_desk == 1 || goal_location_desk == 3) {
                // 桌子
                grasp.ur_10_service_move(3,1);
                grasp.twist_service(-1,90);
                grasp.run(10,DESK); // 桌子的10右观察点
                grasp.run(12,DESK);  //桌子的12左观察点
                grasp.ur_10_service_move(3,1);
                grasp.twist_service(-1,90);


            } else if (goal_location_desk == 2 || goal_location_desk == 4) {
                // 柜子
                grasp.ur_10_service_move(3,1);
                grasp.twist_service(-1,90);
                grasp.run(4,CABINET);
                grasp.run(6,CABINET);
                grasp.run(8,CABINET);
                grasp.run(9,CABINET);
                grasp.run(7,CABINET);
                grasp.run(5,CABINET);
                grasp.ur_10_service_move(3,1);
                grasp.twist_service(-1,90);
            }
            desk_flag[goal_location_desk] = 1;

        }
        for(int i=0;i<4;i++)
        {
            if(desk_flag[i] == 2)
                desk_flag[i] = 0;
        }
    }
    int ss = 1;
    ss = grasp.agv_move2_service(point[checkout_side], 0);
    while(ss == 0)
    {
        ss = grasp.agv_move2_service(point[checkout_side], 0);
    }
    ss = grasp.agv_move2_service(point[checkout_side+1], 1);
    grasp.twist_service(-1,0);
    grasp.ur_10_service_move(13,1);

    return 0;
}
